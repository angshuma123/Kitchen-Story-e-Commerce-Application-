package com.simplilearn.kitchenStoryFoods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KitchenStoryFoodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(KitchenStoryFoodsApplication.class, args);
	}

}
