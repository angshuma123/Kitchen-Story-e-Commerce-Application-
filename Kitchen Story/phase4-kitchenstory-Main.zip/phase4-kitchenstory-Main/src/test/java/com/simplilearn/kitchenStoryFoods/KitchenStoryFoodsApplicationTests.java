package com.simplilearn.kitchenStoryFoods;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KitchenStoryFoodsApplicationTests {

	@Test
	void contextLoads() {
	}

}
